package com.example.activitattema8;

import android.os.Bundle;
import android.app.Activity;
import android.widget.RelativeLayout;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RelativeLayout gameLayout = findViewById(R.id.game_layout);

        GameView gameView = new GameView(this);

        gameLayout.addView(gameView);
    }
}