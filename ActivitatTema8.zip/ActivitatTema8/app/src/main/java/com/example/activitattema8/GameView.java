package com.example.activitattema8;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

public class GameView extends View {
    private Bitmap invaderBitmap;
    private Bitmap starshipBitmap;
    private Paint paint = new Paint();

    public GameView(Context context) {
        super(context);

        invaderBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.invader);
        starshipBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.starship);

        invaderBitmap = Bitmap.createScaledBitmap(invaderBitmap, 80, 80, false);
        starshipBitmap = Bitmap.createScaledBitmap(starshipBitmap, 150, 100, false);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawColor(android.graphics.Color.BLACK);

        int cols = 5;
        int rows = 5;
        int spacing = 15;
        int startX = 40;
        int startY = 40;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int x = startX + j * (invaderBitmap.getWidth() + spacing);
                int y = startY + i * (invaderBitmap.getHeight() + spacing);
                canvas.drawBitmap(invaderBitmap, x, y, paint);
            }
        }

        int playerX = (canvas.getWidth() - starshipBitmap.getWidth()) / 2;
        int playerY = canvas.getHeight() - starshipBitmap.getHeight() - 50;
        canvas.drawBitmap(starshipBitmap, playerX, playerY, paint);
    }
}

